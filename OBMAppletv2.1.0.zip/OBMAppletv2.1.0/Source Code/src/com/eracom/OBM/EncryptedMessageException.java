package com.eracom.OBM;

public class EncryptedMessageException extends Exception
{
  /**
   * Constructors for EncryptedMessageException
   */
    static final long serialVersionUID = -2740153767582114766L;
  public EncryptedMessageException()
  {
    super();
  }

  public EncryptedMessageException(String msg)
  {
    super(msg);
  }
}

