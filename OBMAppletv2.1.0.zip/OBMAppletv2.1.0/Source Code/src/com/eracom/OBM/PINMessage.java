/*************************************************************************************

    Project Name : End-to_End Password Encryption
    Module Name : PINMessage.java (part of EEPEncryptor package)
    Scope : This module provides a PINBlock class which can be constructed either from
    a single PIN Block, or 2 PIN Blocks, and a Random Number string. The methods of this
    class provide representation of this block as a byte array or as a String.
    Purpose : To provide a class which makes it easy to create and use a PIN Message.
    Original Author : Jeff Manson
    Date Created : 1/7/04
    Notes : The following functions are defined in this module :

       getBytes() - method which returns the byte array representation of the PIN Message.
   
***************************************************************************************/

package com.eracom.OBM;

import java.util.Vector;

public class PINMessage implements Custom , Constants
{
  // constants
  private static final byte ONE_PIN_BLOCK_IN_MESSAGE = 1;
  private static final byte TWO_PIN_BLOCKS_IN_MESSAGE = 2;
  private static final int OAEP_SHA1_OFFSET_IN_BYTES = 42;
  private static final int OAEP_SHA2_224_OFFSET_IN_BYTES = 58;
  private static final int OAEP_SHA2_256_OFFSET_IN_BYTES = 66;
  private static final int OAEP_SHA2_384_OFFSET_IN_BYTES = 98;
  private static final int OAEP_SHA2_512_OFFSET_IN_BYTES = 130;

  private static final int MIN_PIN_BLOCK_SIZE = 8;
  private static final int PIN_MESSAGE_TYPE_SIZE = 1;
  private static final int NUM_OF_NIBBLES_PER_BYTE = 2;
  private static final int MIN_RANDOM_NUMBER_STRING_LENGTH = MIN_PIN_BLOCK_SIZE * NUM_OF_NIBBLES_PER_BYTE;


  private static int MAX_MESSAGE_SIZE_IN_BYTES = OBMApplet.RSA_MODULUS_SIZE_IN_BYTES - OAEP_SHA1_OFFSET_IN_BYTES;
  private static int MAX_RANDOM_NUMBER_SIZE_IN_BYTES = MAX_MESSAGE_SIZE_IN_BYTES - MIN_PIN_BLOCK_SIZE - PIN_MESSAGE_TYPE_SIZE;
  private static int MAX_RANDOM_NUMBER_STRING_LENGTH = MAX_RANDOM_NUMBER_SIZE_IN_BYTES * NUM_OF_NIBBLES_PER_BYTE;

  // variables
  private byte [] pinMessageArray;
  private Vector pinMessageVector;
  private int pinMessageLength;
  private byte pinMessageType;
  
  // constructors
  public PINMessage(PINBlock pinBlock, String RN_String) throws PINMessageException
  { 
	if(customer == UOB)
	{
		MAX_MESSAGE_SIZE_IN_BYTES = OBMApplet.RSA_MODULUS_SIZE_IN_BYTES - OAEP_SHA1_OFFSET_IN_BYTES;
		MAX_RANDOM_NUMBER_SIZE_IN_BYTES = MAX_MESSAGE_SIZE_IN_BYTES - MIN_PIN_BLOCK_SIZE - PIN_MESSAGE_TYPE_SIZE;
		MAX_RANDOM_NUMBER_STRING_LENGTH = MAX_RANDOM_NUMBER_SIZE_IN_BYTES * NUM_OF_NIBBLES_PER_BYTE;
	}
  	pinMessageArray = new byte[MAX_MESSAGE_SIZE_IN_BYTES]; 	
  	pinMessageType = ONE_PIN_BLOCK_IN_MESSAGE;  	
	pinMessageArray[0] = pinMessageType;
	pinMessageLength = 1;
	try
	{
		addPinBlockToMessageArray(pinBlock);
		addRandomStringToMessageArray(RN_String);		
		pinMessageVector = new Vector(pinMessageLength);
	    copyByteArrayIntoVector(pinMessageArray, pinMessageVector, pinMessageLength);   
	}
	catch (ArrayIndexOutOfBoundsException e)
	{
		throw new PINMessageException("Error no : " + ERR_INVALID_PIN_LENGTH + " - Invalid PIN length");
	}
     
  }
  
  public PINMessage(PINBlock pinBlock, String RN_String, String Hash_String) throws PINMessageException
  { 
	if(customer == UOB)
	{
		MAX_MESSAGE_SIZE_IN_BYTES = OBMApplet.RSA_MODULUS_SIZE_IN_BYTES - OAEP_SHA1_OFFSET_IN_BYTES;
		MAX_RANDOM_NUMBER_SIZE_IN_BYTES = MAX_MESSAGE_SIZE_IN_BYTES - MIN_PIN_BLOCK_SIZE - PIN_MESSAGE_TYPE_SIZE;
		MAX_RANDOM_NUMBER_STRING_LENGTH = MAX_RANDOM_NUMBER_SIZE_IN_BYTES * NUM_OF_NIBBLES_PER_BYTE;
	}
	
	if(Hash_String.equalsIgnoreCase("SHA1"))
	{
		MAX_MESSAGE_SIZE_IN_BYTES = OBMApplet.RSA_MODULUS_SIZE_IN_BYTES - OAEP_SHA1_OFFSET_IN_BYTES;
	}
	else if(Hash_String.equalsIgnoreCase("SHA2-224"))
	{
		MAX_MESSAGE_SIZE_IN_BYTES = OBMApplet.RSA_MODULUS_SIZE_IN_BYTES - OAEP_SHA2_224_OFFSET_IN_BYTES;	
	}
	else if(Hash_String.equalsIgnoreCase("SHA2-256"))
	{
		MAX_MESSAGE_SIZE_IN_BYTES = OBMApplet.RSA_MODULUS_SIZE_IN_BYTES - OAEP_SHA2_256_OFFSET_IN_BYTES;
	}
	else if(Hash_String.equalsIgnoreCase("SHA2-384"))
	{
		MAX_MESSAGE_SIZE_IN_BYTES = OBMApplet.RSA_MODULUS_SIZE_IN_BYTES - OAEP_SHA2_384_OFFSET_IN_BYTES;		
	}
	else if(Hash_String.equalsIgnoreCase("SHA2-512"))
	{
		MAX_MESSAGE_SIZE_IN_BYTES = OBMApplet.RSA_MODULUS_SIZE_IN_BYTES - OAEP_SHA2_512_OFFSET_IN_BYTES;	
	}
	else
	{
		throw new PINMessageException("Error No: " + ERR_INVALID_HASH + " Invalid Hash Algorithm ");
	}
  	pinMessageArray = new byte[MAX_MESSAGE_SIZE_IN_BYTES]; 	
  	pinMessageType = ONE_PIN_BLOCK_IN_MESSAGE;  	
	pinMessageArray[0] = pinMessageType;
	pinMessageLength = 1;
	try
	{
		addPinBlockToMessageArray(pinBlock);
		addRandomStringToMessageArray(RN_String);	
		pinMessageVector = new Vector(pinMessageLength);
	    copyByteArrayIntoVector(pinMessageArray, pinMessageVector, pinMessageLength);
	}
	catch (ArrayIndexOutOfBoundsException e)
	{
		throw new PINMessageException("Error no : " + ERR_INVALID_PIN_LENGTH + " - Invalid PIN length");
	}
     
  }

  public PINMessage(PINBlock oldPINBlock, PINBlock newPINBlock, String RN_String) throws PINMessageException
  {
	
	if(customer == UOB)
	{
		MAX_MESSAGE_SIZE_IN_BYTES = OBMApplet.RSA_MODULUS_SIZE_IN_BYTES - OAEP_SHA1_OFFSET_IN_BYTES;
		MAX_RANDOM_NUMBER_SIZE_IN_BYTES = MAX_MESSAGE_SIZE_IN_BYTES - MIN_PIN_BLOCK_SIZE - PIN_MESSAGE_TYPE_SIZE;
		MAX_RANDOM_NUMBER_STRING_LENGTH = MAX_RANDOM_NUMBER_SIZE_IN_BYTES * NUM_OF_NIBBLES_PER_BYTE;
	}

  	pinMessageArray = new byte[MAX_MESSAGE_SIZE_IN_BYTES]; 	
  	pinMessageType = TWO_PIN_BLOCKS_IN_MESSAGE;  	
	pinMessageArray[0] = pinMessageType;
	pinMessageLength = 1;	
	try
	{
		addPinBlockToMessageArray(oldPINBlock);
		addPinBlockToMessageArray(newPINBlock);
		addRandomStringToMessageArray(RN_String);
		pinMessageVector = new Vector(pinMessageLength);
		copyByteArrayIntoVector(pinMessageArray, pinMessageVector, pinMessageLength);     
	}
	catch (ArrayIndexOutOfBoundsException e)
	{
		throw new PINMessageException("Error no : " + ERR_INVALID_PIN_LENGTH + " - Invalid PIN length");
	}
  	 
  }
  public PINMessage(PINBlock oldPINBlock, PINBlock newPINBlock, String RN_String, String Hash_String) throws PINMessageException
  {
	
	;if(customer == UOB)
	{
		MAX_MESSAGE_SIZE_IN_BYTES = OBMApplet.RSA_MODULUS_SIZE_IN_BYTES - OAEP_SHA1_OFFSET_IN_BYTES;
		MAX_RANDOM_NUMBER_SIZE_IN_BYTES = MAX_MESSAGE_SIZE_IN_BYTES - MIN_PIN_BLOCK_SIZE - PIN_MESSAGE_TYPE_SIZE;
		MAX_RANDOM_NUMBER_STRING_LENGTH = MAX_RANDOM_NUMBER_SIZE_IN_BYTES * NUM_OF_NIBBLES_PER_BYTE;
	}
	
	if(Hash_String.equalsIgnoreCase("SHA1"))
	{
		MAX_MESSAGE_SIZE_IN_BYTES = OBMApplet.RSA_MODULUS_SIZE_IN_BYTES - OAEP_SHA1_OFFSET_IN_BYTES;
	}
	else if(Hash_String.equalsIgnoreCase("SHA2-224"))
	{
		MAX_MESSAGE_SIZE_IN_BYTES = OBMApplet.RSA_MODULUS_SIZE_IN_BYTES - OAEP_SHA2_224_OFFSET_IN_BYTES;	
	}
	else if(Hash_String.equalsIgnoreCase("SHA2-256"))
	{
		MAX_MESSAGE_SIZE_IN_BYTES = OBMApplet.RSA_MODULUS_SIZE_IN_BYTES - OAEP_SHA2_256_OFFSET_IN_BYTES;
	}
	else if(Hash_String.equalsIgnoreCase("SHA2-384"))
	{
		MAX_MESSAGE_SIZE_IN_BYTES = OBMApplet.RSA_MODULUS_SIZE_IN_BYTES - OAEP_SHA2_384_OFFSET_IN_BYTES;		
	}
	else if(Hash_String.equalsIgnoreCase("SHA2-512"))
	{
		MAX_MESSAGE_SIZE_IN_BYTES = OBMApplet.RSA_MODULUS_SIZE_IN_BYTES - OAEP_SHA2_512_OFFSET_IN_BYTES;	
	}
	else
	{
		throw new PINMessageException("Error No: " + ERR_INVALID_HASH + " Invalid Hash Algorithm ");
	}


  	pinMessageArray = new byte[MAX_MESSAGE_SIZE_IN_BYTES]; 	
  	pinMessageType = TWO_PIN_BLOCKS_IN_MESSAGE;  	
	pinMessageArray[0] = pinMessageType;
	pinMessageLength = 1;	
	try
	{
		addPinBlockToMessageArray(oldPINBlock);
		addPinBlockToMessageArray(newPINBlock);
		addRandomStringToMessageArray(RN_String);
		pinMessageVector = new Vector(pinMessageLength);
		copyByteArrayIntoVector(pinMessageArray, pinMessageVector, pinMessageLength);     
	}
	catch (ArrayIndexOutOfBoundsException e)
	{
		throw new PINMessageException("Error no : " + ERR_INVALID_PIN_LENGTH + " - Invalid PIN length");
	}
  	 
  }
  
  private void addPinBlockToMessageArray(PINBlock pinBlock) throws PINMessageException
  {
  	int pinBlockLength;
  	byte [] pinBlockByteArray;
  	
	if (pinBlock == null)
	{
  	  throw new PINMessageException("Error no : " + ERR_INVALID_PIN_BLOCK + " - Invalid PIN Block");
	}
	
  	pinBlockLength = pinBlock.length();
   	pinBlockByteArray = pinBlock.getBytes();  
   	System.arraycopy(pinBlockByteArray, 0, pinMessageArray, pinMessageLength, pinBlockLength);	    
	pinMessageLength = pinMessageLength + pinBlockLength;
	return;
  }
  
  private void addRandomStringToMessageArray(String RN_String) throws PINMessageException
  {
  	int RNStringLength, RNByteLength, maxRandomNumberStringSize, conversionError;
  	
	if (RN_String == null)
	{
  	  throw new PINMessageException("Error no : " + ERR_INVALID_RANDOM_NUMBER + " - Invalid Random Number String");
	}
	
  	RNStringLength = RN_String.length();
  	RNByteLength = (RNStringLength + 1) / 2;
  	
    maxRandomNumberStringSize = (MAX_MESSAGE_SIZE_IN_BYTES - pinMessageLength) * NUM_OF_NIBBLES_PER_BYTE;
 
	if (RNStringLength < MIN_RANDOM_NUMBER_STRING_LENGTH ||
	    RNStringLength > maxRandomNumberStringSize ||
	    RNStringLength != (RNByteLength * 2))					// checks for odd no of hex chars
	{
		
	
  		throw new PINMessageException("Error no : " + ERR_INVALID_RANDOM_NUMBER_LENGTH + " - Invalid Random Number String length");
	}
	
 	conversionError = OBMApplet.convertStringToPackedHexByteArray(RN_String, pinMessageArray, pinMessageLength);
	
	if (conversionError != OBMApplet.NO_HEX_CONVERSION_ERRORS)
	{
  	  throw new PINMessageException("Error no : " + ERR_INVALID_RANDOM_NUMBER + " - Invalid Random Number String");
	}
	
	pinMessageLength = pinMessageLength + RNByteLength;
  		
  	return;
  }


  private void copyByteArrayIntoVector(byte[] byteArray, Vector vector, int numOfBytesToCopy)
  {
  	for (int index = 0; index < numOfBytesToCopy; index++)
  	{ 
  	  vector.addElement(new Byte(byteArray[index]));
  	}
  	
  	return;
  }
  
  public Vector getMsgVector()
  {   		
  	return pinMessageVector;
  }

  public void getBytes(Byte[] byteArray)
  {  
  	int totalElementsInVector;
  	
  	totalElementsInVector = pinMessageVector.size(); 		

  	for (int index = 0; index < totalElementsInVector; index++)
  	{ 
  	  byteArray[index] = (Byte) pinMessageVector.elementAt(index);
  	}
  	return;
  }

  public int length()
  {
  	return pinMessageLength; 	
  }
}

