/*************************************************************************************

    Copyright (C) Safenet, Inc 2008
    All Rights Reserved - Proprietary Information of Safenet, Inc.
    Not to be Construed as a Published Work.

**************************************************************************************

    Project Name : Online Banking Support Module
    Module Name : OBM.java (part of OBM package)
    Scope : This module includes main OBM applet and all functions required to
            transfer data to/from JavaScript on the user's web page.
    Purpose : To provide the JavaScript Password Encryption methods and
              the main OBM Applet.
    Original Author : Jeff Manson
    Date Created : 1/7/04
    Notes : The following functions are defined in this module :

       encryptPassword() - method called by Javascript to encrypt a user password.
   
       encryptChangePassword() - method called by Javascript to encrypt a Change password.
	   getEncryptedPassword() - accessor method to return encrypted user password message
	                                (ie. C_String) to Javascript.
	   getEncodingParameter() - accessor method to return Encoding Parameter (ie. P_String)
	                            to Javascript.
	                                                         
    Change History :

    Change No    Date        Author             Details
       0	 	1/7/04     J. Manson       Initial Creation

***************************************************************************************/

package com.eracom.OBM;

import java.applet.Applet;
import java.util.Vector;
import java.net.URL;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.math.BigInteger;

public class OBMApplet extends Applet implements Custom, Constants
{
  /*version */
  static final long serialVersionUID = -2740153767582114766L;
  private static final String version = "1.1.0";		
  // constants
  public static final int INVALID_HEX_CHAR_ERROR = 1;
  public static final int NOT_VALID_HEX_CHARACTER = -1;
  public static final int NO_HEX_CONVERSION_ERRORS = 0;
  public static final int ASCII_ZERO_CHARACTER = 0x30;

  protected static final int HEX_RADIX = 16;

  // Public Key Data Constants
  public static int RSA_MODULUS_SIZE_IN_BYTES = PublicKeyData.RSA_MODULUS_SIZE_IN_BITS / 8;
  public static String PUBLIC_EXPONENT_STRING = PublicKeyData.PUBLIC_EXPONENT_STRING;
  public static String MODULUS_STRING = PublicKeyData.MODULUS_STRING;

  protected static int MAX_RSA_MODULUS_SIZE_IN_BYTES = MAX_RSA_MODULUS_SIZE_IN_BITS / 8;
  protected static int MIN_RSA_MODULUS_SIZE_IN_BYTES = MIN_RSA_MODULUS_SIZE_IN_BITS / 8;
  protected static int DECRYPTION_RSA_MODULUS_SIZE_IN_BITS = 1288;
  protected static int MAX_ENC_PUBLIC_KEY_DATA_SIZE_IN_BYTES = DECRYPTION_RSA_MODULUS_SIZE_IN_BITS / 8;
  protected static String DECRYPTION_PUBLIC_EXPONENT_STRING = "000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000A5D9";
  protected static String DECRYPTION_MODULUS_STRING =         "92929FA6199A7586EF87BD243DE1273EE122CCDB4D4BFB3CBA75C8E3855E9D42157566E0E06C15EAA9D728ED531C4858D616C4FEE7F6AE75914ECE60F41FD9F0AF89DEB5FDB54771AE2D1DB2B325000003FA2A40EA972185E9826D15E2977C41E995B751D795499CA1DACCD1B7C1CE16E36727B5C512A7BDE3F4DFBDB6726703C0E4C3141E1FAC1BD7051ECD1011571EC9FAB1608535DFE8FFBD6A4BB94737AE43";

  protected boolean isPublicKeyDataValid = false;
  // variables
  private String C_String = "";
  private String P_String = "";
	
  public void init()
  {   
  	// initialise Public key data values
    if (!initialisePublicKeyData())
    {
		if(customer != UOB)
		{
		  System.out.println("Unable to initialise Public Key Data");
		}
  	  return;
    }
    
    isPublicKeyDataValid = true;
     
	// display message in Java console to show that Applet has started ok
	if(customer != UOB)
	{
		System.out.println("Applet initialised ok");
	}
	return;
  }
	
 /**
  * @brief OBM_EncryptPassword
  *
  * This method encodes and encrypts a user password in a form that can
  * be sent to the HSM to set a password. The function is meant to be called
  * from Javascript.
  *
  * @param [in]  pinString     Password to be encrypted. Passed as ASCII 
  *                            characters. The password will be formatted
  *                            as a Format 12 PIN block.
  * @param [in]  RN_String     Random number as a string of hex digits as
  *                            generated in ESM and sent to Javascript.
  *                            
  * @note The encoded and encrypted password is stored in a private
  *       variable and can be retrieved via the accessor method
  *       OBM_Get_Encrypted_Password.
  *
  * @return ERR_NO_ERROR       Success
  * @return ERR_INVALID_PIN    Invalid password ...
  */
  
  public int OBM_EncryptPassword(String pinString, String RN_String)
  {
  	byte [] encMsgArray;
  	
  	if (!isPublicKeyDataValid)
  	{
  	  return ERR_INVALID_RSA_KEY;
  	}
  	
	try
	{
	  PINBlock pinBlock = new PINBlock(pinString);
	  PINMessage pinMessage = new PINMessage(pinBlock, RN_String);
	  OAEPEncodedMessage oaepEncMessage = new OAEPEncodedMessage(pinMessage);
	  P_String = oaepEncMessage.getEncodingParameter();
	  EncryptedMessage encMessage = new EncryptedMessage(oaepEncMessage);
	  encMsgArray = encMessage.getBytes();
	  C_String = convertHexArrayToString(encMsgArray);
      return ERR_NO_ERROR;
	}
	catch (PINBlockException e)
	{
	  return getErrorCode(e.getMessage());
	}
	catch (PINMessageException e)
	{
	  return getErrorCode(e.getMessage());
	}
    catch (EncryptedMessageException e)
    {
	  return getErrorCode(e.getMessage());
    }
    catch (OAEPEncodedMsgException e)
    {
	  return getErrorCode(e.getMessage());
    }
  }
   
  /**
  * @brief OBM_EncryptChangedPassword
  *
  * This method encodes and encrypts an old and new user password in a form
  * that can be sent to the ESM to effect a password change. The function
  * is meant to be called from Javascript.
  *
  * @param [in]  oldPinString  Original password as a string of ASCII
  *                            characters.
  * @param [in]  newPinString  New password as a string of ASCII characters.
  * @param [in]  RN_String     Random number as a string of hex digits as
  *                            generated in ESM and sent to Javascript.
  *                            
  * @note The encoded and encrypted password message is stored in a private
  *       variable and can be retrieved via the accessor method
  *       OBM_Get_Encrypted_Password.
  *
  * @return ERR_NO_ERROR       Success
  * @return ERR_INVALID_PIN    Invalid password ...
  */ 

  public int OBM_EncryptChangePassword(String oldPINString,
                                       String newPINString,
                                       String RN_String)
  {
  	byte [] encMsgArray;

  	if (!isPublicKeyDataValid)
  	{
  	  return ERR_INVALID_RSA_KEY;
  	}
  	
	try
	{
	  
	
	  PINBlock oldPinBlock = new PINBlock(oldPINString);
	  PINBlock newPinBlock = new PINBlock(newPINString);

	  /* check if pin blocks are same*/
  	  if(customer == UOB)
	  {
		if(oldPINString.compareTo(newPINString) == 0){
			if(customer != UOB)
			{
				String errorNumberString = "Error no : " + ERR_OLD_NEW_PASSWORD_SAME + " Old and New Password Same";
				System.out.println(errorNumberString);
			}
			return ERR_OLD_NEW_PASSWORD_SAME;
		}
	  }
	  PINMessage pinMessage = new PINMessage(oldPinBlock, newPinBlock, RN_String);
	  OAEPEncodedMessage oaepEncMessage = new OAEPEncodedMessage(pinMessage);
	  P_String = oaepEncMessage.getEncodingParameter();
	  EncryptedMessage encMessage = new EncryptedMessage(oaepEncMessage);
	  encMsgArray = encMessage.getBytes();
	  C_String = convertHexArrayToString(encMsgArray);
      return ERR_NO_ERROR;
    }
	catch (PINBlockException e)
	{
	  return getErrorCode(e.getMessage());
	}
	catch (PINMessageException e)
	{
	  return getErrorCode(e.getMessage());
	}
    catch (EncryptedMessageException e)
    {
	  return getErrorCode(e.getMessage());
    }
    catch (OAEPEncodedMsgException e)
    {
	  return getErrorCode(e.getMessage());
    }
  }

/**
   * @brief OBM_EncryptPassword_Ex
   *
   * This method encodes and encrypts a user password in a form that can
   * be sent to the HSM to set a password. The function is meant to be called
   * from Javascript.
   *
   * @param [in]  pinString     Password to be encrypted. Passed as ASCII 
   *                            characters. The password will be formatted
   *                            as a Format 12 PIN block.
   * @param [in]  RN_String     Random number as a string of hex digits as
   *                            generated in ESM and sent to Javascript.
   * @param [in]  Hash_String   Hash Algorithm to be used for encryption
   *                            Allowed values: SHA1, SHA2-224, SHA2-256, 
   *                            SHA2-384, SHA2-512.                           
   *                            
   * @note The encoded and encrypted password is stored in a private
   *       variable and can be retrieved via the accessor method
   *       OBM_Get_Encrypted_Password.
   *
   * @return ERR_NO_ERROR       Success
   * @return ERR_INVALID_PIN    Invalid password ...
   */
   
   public int OBM_EncryptPassword_Ex(String pinString, String RN_String,String Hash_String)
   {
   	byte [] encMsgArray;
   	
   	if (!isPublicKeyDataValid)
   	{
   	  return ERR_INVALID_RSA_KEY;
   	}
   	
 	try
 	{
 		if (Hash_String == null)
 		{
 	  	  return ERR_INVALID_HASH;
 		}
 		if((Hash_String.equalsIgnoreCase("SHA2-384") && RSA_MODULUS_SIZE_IN_BYTES < 112)
 			||(Hash_String.equalsIgnoreCase("SHA2-512") && RSA_MODULUS_SIZE_IN_BYTES < 144))
 		{
 			return ERR_INVALID_RSA_KEY_LENGTH;
 		}
 	  PINBlock pinBlock = new PINBlock(pinString);
 	  PINMessage pinMessage = new PINMessage(pinBlock, RN_String, Hash_String);
 	  OAEPEncodedMessage oaepEncMessage = new OAEPEncodedMessage(pinMessage,Hash_String);
 	  P_String = oaepEncMessage.getEncodingParameter();
 	  //System.out.println("P is "+ P_String);
 	  EncryptedMessage encMessage = new EncryptedMessage(oaepEncMessage);
 	  encMsgArray = encMessage.getBytes();
 	  C_String = convertHexArrayToString(encMsgArray);
 	  //System.out.println("C is "+ C_String);
       return ERR_NO_ERROR;
 	}
 	catch (PINBlockException e)
 	{
 	  return getErrorCode(e.getMessage());
 	}
 	catch (PINMessageException e)
 	{
 	  return getErrorCode(e.getMessage());
 	}
     catch (EncryptedMessageException e)
     {
 	  return getErrorCode(e.getMessage());
     }
     catch (OAEPEncodedMsgException e)
     {
 	  return getErrorCode(e.getMessage());
     }
   }
 

/**
  * @brief OBM_EncryptChangedPassword_ex
  *
  * This method encodes and encrypts an old and new user password in a form
  * that can be sent to the ESM to effect a password change. The function
  * is meant to be called from Javascript.
  *
  * @param [in]  oldPinString  Original password as a string of ASCII
  *                            characters.
  * @param [in]  newPinString  New password as a string of ASCII characters.
  * @param [in]  RN_String     Random number as a string of hex digits as
  *                            generated in ESM and sent to Javascript.
  * @param [in]  Hash_String   Hash Algorithm to be used for encryption
  *                            Allowed values: SHA1, SHA2-224, SHA2-256, 
  *                            SHA2-384, SHA2-512.     
  *                                                        
  * @note The encoded and encrypted password message is stored in a private
  *       variable and can be retrieved via the accessor method
  *       OBM_Get_Encrypted_Password.
  *
  * @return ERR_NO_ERROR       Success
  * @return ERR_INVALID_PIN    Invalid password ...
  */ 

  public int OBM_EncryptChangePassword_Ex(String oldPINString,
                                       String newPINString,
                                       String RN_String,
                                       String Hash_String)
  {
  	byte [] encMsgArray;

  	if (!isPublicKeyDataValid)
  	{
  	  return ERR_INVALID_RSA_KEY;
  	}
  	
	try
	{
		if (Hash_String == null)
 		{
 	  	  return ERR_INVALID_HASH;
 		}
		if((Hash_String.equalsIgnoreCase("SHA2-384") && RSA_MODULUS_SIZE_IN_BYTES < 112)
	 			||(Hash_String.equalsIgnoreCase("SHA2-512") && RSA_MODULUS_SIZE_IN_BYTES < 144))
	 		{
	 			return ERR_INVALID_RSA_KEY_LENGTH;
	 		}
	  PINBlock oldPinBlock = new PINBlock(oldPINString);
	  PINBlock newPinBlock = new PINBlock(newPINString);

	  /* check if pin blocks are same*/
  	  if(customer == UOB)
	  {
		if(oldPINString.compareTo(newPINString) == 0){
			if(customer != UOB)
			{
				String errorNumberString = "Error no : " + ERR_OLD_NEW_PASSWORD_SAME + " Old and New Password Same";
				System.out.println(errorNumberString);
			}
			return ERR_OLD_NEW_PASSWORD_SAME;
		}
	  }
	  PINMessage pinMessage = new PINMessage(oldPinBlock, newPinBlock, RN_String, Hash_String);
	  OAEPEncodedMessage oaepEncMessage = new OAEPEncodedMessage(pinMessage, Hash_String);
	  P_String = oaepEncMessage.getEncodingParameter();
	  //System.out.println("P is "+ P_String);
	  EncryptedMessage encMessage = new EncryptedMessage(oaepEncMessage);
	  encMsgArray = encMessage.getBytes();
	  C_String = convertHexArrayToString(encMsgArray);
	  //System.out.println("C is "+ C_String);
      return ERR_NO_ERROR;
    }
	catch (PINBlockException e)
	{
	  return getErrorCode(e.getMessage());
	}
	catch (PINMessageException e)
	{
	  return getErrorCode(e.getMessage());
	}
    catch (EncryptedMessageException e)
    {
	  return getErrorCode(e.getMessage());
    }
    catch (OAEPEncodedMsgException e)
    {
	  return getErrorCode(e.getMessage());
    }
  }
 	
  /**
  * @brief OBM_GetEncryptedPassword
  *
  * This is an accessor method to return a previously encrypted password.
  *
  * @param None
  *                            
  * @note The encoded and encrypted password message is stored in a private
  *       variable and can be retrieved via the accessor method
  *       OBM_Get_Encrypted_Password.
  *
  * @return C_String    Encrypted message as string of hex digits calculated
  *                     in OBM_EncryptPassword and OBM_EncryptChangedPassword
  *                     methods.
  */  
  public String OBM_GetEncryptedPassword()
  {
    return C_String;
  }
   
  /**
  * @brief OBM_GetEncodingParameter
  *
  * This is an accessor method to return a previously generated encoding
  * parameter.
  *
  * @param None
  *                            
  * @return P_String    Encoding Parameter generated by applet and passed to
  *                     Javascript. It is a String of 32 hex digits
  *                     (ie. 16 bytes).
  */  
  public String OBM_GetEncodingParameter()
  {
    return P_String;
  }
  
  private int getErrorCode(String errorMessage)
  {
  	String errorNumberString = "Error no : ";
  	int errorNumberOffset, errorNumberIndex, errorNumber;
	int errorNumberSize = 2;								// allow for 2-digit error numbers
  	
  	errorNumberOffset = errorNumberString.length(); 
	errorNumberIndex = errorMessage.indexOf(errorNumberString) + errorNumberOffset;
	errorNumber = Integer.parseInt(errorMessage.substring(errorNumberIndex, (errorNumberIndex + errorNumberSize)));
    if(customer != UOB)
	{
		System.out.println(errorMessage);
	}
	return errorNumber;
  }		
 
  private boolean initialisePublicKeyData()
  {
	// check that Public key data values have been initialised
	if (RSA_MODULUS_SIZE_IN_BYTES == 0 ||
  	    PUBLIC_EXPONENT_STRING == null ||
  	    MODULUS_STRING == null)
  	{
		/*
		* Note :  call to getSerialisedPublicKeyData is commented out because OBM doesn't support RSA public key initialization from a file.
		*/
  		/* return getSerialisedPublicKeyData(); */
	  return false;
	
  	}
    return true;
  }
  
  private boolean getSerialisedPublicKeyData()
  {
  	String publicExponentString, modulusString;
  	URL publicKeyDataFileURL = null;
  	InputStream serializedPublicKeyDataFile;
  	
	// look for encrypted serialised public key data file and if not found, try
  	// un-encrypted data file. If both not found, just return failure.
    try
    {
      publicKeyDataFileURL = new URL(this.getCodeBase(), "encpk.ser");
      serializedPublicKeyDataFile = publicKeyDataFileURL.openStream();
    }
    catch (Exception e) 
    {
		if(customer != UOB)
		{
			System.out.println("Public Key data file URL : " + publicKeyDataFileURL);
			System.out.println("Public Key data file not found");
		}
  	    return false;
    }
  	
    try
    {
      ObjectInputStream publicKeyDataInputStream = new ObjectInputStream(serializedPublicKeyDataFile);
      RSA_MODULUS_SIZE_IN_BYTES = ((Integer) publicKeyDataInputStream.readObject()).intValue() / 8;
      publicExponentString = (String) publicKeyDataInputStream.readObject();
      modulusString = (String) publicKeyDataInputStream.readObject();
    }
    catch (Exception e) 
    {
		if(customer != UOB)
		{
			System.out.println("Exception - " + e.getMessage());
		}
	  return false;
    }
  	
    // check that input data size < key size
  	if ((RSA_MODULUS_SIZE_IN_BYTES > MAX_RSA_MODULUS_SIZE_IN_BYTES) ||
  	    (RSA_MODULUS_SIZE_IN_BYTES < MIN_RSA_MODULUS_SIZE_IN_BYTES))
  	{
      //System.out.println("Invalid Public Key modulus size");
      //System.out.println("RSA_MODULUS_SIZE_IN_BYTES = " + RSA_MODULUS_SIZE_IN_BYTES);
	  return false;
  	}
  	
    BigInteger decryptionPublicExponent, decryptionModulus;
  	decryptionPublicExponent = new BigInteger(DECRYPTION_PUBLIC_EXPONENT_STRING, HEX_RADIX);
    decryptionModulus = new BigInteger(DECRYPTION_MODULUS_STRING, HEX_RADIX);
    PUBLIC_EXPONENT_STRING = decryptPublicKeyDataString(publicExponentString, 
                                                        decryptionPublicExponent,
                                                        decryptionModulus);
    MODULUS_STRING = decryptPublicKeyDataString(modulusString, 
            									decryptionPublicExponent,
            									decryptionModulus);
    return true;
  }
  
  private String decryptPublicKeyDataString(String encryptedDataString, 
                                            BigInteger decryptionPublicExponent,
                                            BigInteger decryptionModulus)
  {
  	BigInteger inputData, outputData;
    byte[] dataByteArray = new byte[MAX_ENC_PUBLIC_KEY_DATA_SIZE_IN_BYTES];
    
    convertStringToPackedHexByteArray(encryptedDataString, dataByteArray, 0);
    inputData = new BigInteger(1, dataByteArray);
  	outputData = inputData.modPow(decryptionPublicExponent, decryptionModulus);
  	return convertEncDataToPublicKeyString(outputData.toByteArray());
   }
  
  /************************************************************************************

  								Utility Functions 
  			                          
  *************************************************************************************/
  
  public static void fillByteArray(byte[] byteArray, int fillCharacter)
  {
  	int index, byteArrayLength;
  	
  	byteArrayLength = byteArray.length;
  	
  	for (index = 0; index < byteArrayLength; index++)
  	{  		
 	  byteArray[index] = (byte) fillCharacter;
  	}
  		
    return;
  }
  
  public static void convertAsciiArrayToHexByteArray(byte[] asciiArray,
                                                     byte [] hexByteArray,
                                                     int HexByteArrayOffset,
                                                     int asciiArrayLength)
  {
    final int NUM_OF_NIBBLES_PER_BYTE = 2;
    
  	int tempInt, byteCount, digitCount, byteLength;
  	
  	byteLength = (asciiArrayLength + 1) / 2;
  	
  	for (byteCount = 0, digitCount = 0; byteCount < byteLength; byteCount++)
  	{  		
  	  if (digitCount < (asciiArrayLength - 1))
  	  {
  	    tempInt = ((int) asciiArray[digitCount] & 0x0F) << 4;
  	    tempInt = tempInt | (int) asciiArray[digitCount + 1] & 0x0F;
  	  }
  	  else
  	  {
  	    tempInt = (int) hexByteArray[byteCount + HexByteArrayOffset] & 0x0F;
  	    tempInt = tempInt | ((int) asciiArray[digitCount] & 0x0F) << 4;
  	  }
 	  hexByteArray[byteCount + HexByteArrayOffset] = (byte) tempInt;
 	  digitCount += NUM_OF_NIBBLES_PER_BYTE;
  	}
  	
  	return;
  }
/* convert ascii value string to hax value. A single char is expanded in two hex chars*/

  public static String convertHexArrayToString(byte[] hexArray)
  {
  	StringBuffer byteString = new StringBuffer(); 	
  	int hexArrayLength = hexArray.length;  	
  	int hexValue;
  	char hexChar;
  	
  	for (int index = 0; index < hexArrayLength; index++)
  	{  		
  	  hexValue = (int) (hexArray[index] & 0xF0) >> 4;
  	  hexChar = Character.forDigit(hexValue, HEX_RADIX);
  	  byteString.append(Character.toUpperCase(hexChar));	
  	  hexValue = (int) (hexArray[index] & 0x0F);
  	  hexChar = Character.forDigit(hexValue, HEX_RADIX);
  	  byteString.append(Character.toUpperCase(hexChar));	
  	}
  	
  	return new String(byteString); 	
  }
  
  public static int convertStringToPackedHexByteArray(String inputString, byte[] hexArray, int hexArrayOffset)
  {
  	int stringLength = inputString.length();  	
  	int charCount, byteCount, hexValue, temp;
  	char inputChar;
  	
  	for (charCount = 0, byteCount = 0;charCount < stringLength; charCount++, byteCount++)
  	{  		
  	  inputChar = inputString.charAt(charCount);	  	  		
  	  hexValue = Character.digit(inputChar, HEX_RADIX);
	  if (hexValue == NOT_VALID_HEX_CHARACTER)
	  {
	  	return INVALID_HEX_CHAR_ERROR;
	  }	  
  	  temp = hexValue << 4;
  	  charCount++;
  	  if (charCount < stringLength)
  	  {
  	    inputChar = inputString.charAt(charCount);	  	  		
  	    hexValue = Character.digit(inputChar, HEX_RADIX);
	    if (hexValue == NOT_VALID_HEX_CHARACTER)
	    {
	  	  return INVALID_HEX_CHAR_ERROR;
	    }
  	    hexArray[byteCount + hexArrayOffset] = (byte) (temp | hexValue);
  	  }
  	  else
  	  {
  	    hexArray[byteCount + hexArrayOffset] = (byte) (temp | 0x0F);
  	  }
  	}
  	
  	return NO_HEX_CONVERSION_ERRORS; 	
  }
  
  public static void convertStringtoHexByteArray(String inputString, byte[] byteArray)
  {
  	int inputStringLength = inputString.length();
  	
  	for (int index = 0; index < inputStringLength; index++)
  	{  
 	  byteArray[index] = (byte) inputString.charAt(index);
  	}
  	return;
  }

  public static String convertHexByteVectorToString(Vector hexVector)
  {
  	StringBuffer byteString = new StringBuffer(); 	
  	int hexVectorLength = hexVector.size();
  	Byte vectorValue;  	
  	int hexValue;
  	char hexChar;
  	
  	for (int index = 0; index < hexVectorLength; index++)
  	{ 
  	  vectorValue = (Byte) hexVector.elementAt(index); 		
  	  hexValue = (vectorValue.intValue() & 0xF0) >> 4;
  	  hexChar = Character.forDigit(hexValue, HEX_RADIX);
  	  byteString.append(Character.toUpperCase(hexChar));	
   	  hexValue = vectorValue.intValue() & 0x0F;
  	  hexChar = Character.forDigit(hexValue, HEX_RADIX);
  	  byteString.append(Character.toUpperCase(hexChar));	
  	}
  	
  	return new String(byteString); 	
  }
  
  private String convertEncDataToPublicKeyString(byte [] encDataArray)
  {
  	int encDataArrayLength;
  	
   	encDataArrayLength = encDataArray.length;
   	if (encDataArrayLength == RSA_MODULUS_SIZE_IN_BYTES)
   	{
      return convertHexArrayToString(encDataArray);
    }
   	else
   	{
  	  // adjust the resulting array length to length of public key data
  	  // as we want resulting string to be length of public key data
      int encDataStartOffset, publicKeyDataStartOffset;
      byte[] publicKeyDataArray;
      	
      publicKeyDataArray = new byte[RSA_MODULUS_SIZE_IN_BYTES];
      if (encDataArrayLength > RSA_MODULUS_SIZE_IN_BYTES)
      {
        encDataStartOffset = encDataArrayLength - RSA_MODULUS_SIZE_IN_BYTES;
        encDataArrayLength = RSA_MODULUS_SIZE_IN_BYTES;
        publicKeyDataStartOffset = 0;
      }
      else
      {
        encDataStartOffset = 0;
        publicKeyDataStartOffset = RSA_MODULUS_SIZE_IN_BYTES - encDataArrayLength;
      }
  	  System.arraycopy(encDataArray, encDataStartOffset, publicKeyDataArray, publicKeyDataStartOffset, encDataArrayLength);
  	  return convertHexArrayToString(publicKeyDataArray);
   	}
  }
}
