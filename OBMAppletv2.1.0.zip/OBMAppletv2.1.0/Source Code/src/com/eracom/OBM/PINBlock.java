/*************************************************************************************

    Project Name : End-to_End Password Encryption
    Module Name : PINBlock.java (part of EEPEncryptor package)
    Scope : This module provides a PINBlock class which can be constructed from a
            PIN string and a Random Number string. The methods of this class provide
            representation of this block as a Byte array or as a String.
    Purpose : To provide a class which makes it easy to create and use a PIN block.
    Original Author : Jeff Manson
    Date Created : 1/7/04
    Notes : The following functions are defined in this module :

       getByteArray() - method which returns the Byte array conversion from the HexString
                        object.
   
***************************************************************************************/

package com.eracom.OBM;

public class PINBlock implements Custom, Constants
{
  // constants
  private static final int PIN_BLOCK_FILL_CHARACTER = 0xFF;
  private static final int FMT_2_CONTROL_BYTE = 0x02;
  private static final int FMT_12_CONTROL_BYTE = 0xC1;
  private static final int ISO_FORMAT_2_TYPE = 1;
  private static final int ISO_FORMAT_12_TYPE = 2;

  private static final int MAX_NUMERIC_PIN_STRING_SIZE = 12;
  private static final int MAX_NUMERIC_PIN_BYTE_SIZE = 6;
  private static final int DECIMAL_RADIX = 10;
  private static final int NUM_OF_BYTES_IN_FMT2_PIN_BLOCK = 8;
  private static final int NUM_OF_BYTES_PER_CNTRL_AND_PIN_LENGTH = 2;

  // variables
  private byte [] PINBlockByteArray;
  private int PINLength;
  private int PINBlockType;
  private int numberOfPINBlocks, PINBlockLength;
  
  // constructor
  public PINBlock(String pinString) throws PINBlockException
  {
	ValidateAndCreatePINBlockByteArray(pinString);  	
  }
  
  private void ValidateAndCreatePINBlockByteArray(String pinString) throws PINBlockException
  {
  	int index;
  	byte PinStringByteArray[] = new byte[MAX_PIN_STRING_SIZE];
  	byte numericPinStringByteArray[] = new byte[MAX_NUMERIC_PIN_STRING_SIZE];
  	char pinChar;
  	boolean isInvalidCharFound = false;

  	boolean isPINNumeric = false;
	
	if (pinString == null)
	{
  	  throw new PINBlockException("Error no : " + ERR_INVALID_PIN + " - Invalid PIN String");
	}
	
  	PINLength = pinString.length();
  	if (PINLength > MAX_PIN_STRING_SIZE ||
  	    PINLength < MIN_PIN_STRING_SIZE)
  	{
  	  throw new PINBlockException("Error no : " + ERR_INVALID_PIN_LENGTH + " - Invalid PIN length");
  	}
  	/*
	Note : Below lines has been commented out because OBM applet only supports format 12 pin block.
	Format 2 pin block contains a numeric pin.
/*
 	if (PINLength <= MAX_NUMERIC_PIN_STRING_SIZE)
 	{
  	  isPINNumeric = true;
 	}
*/  	
  	for (index = 0; index < PINLength; index++)
  	{  
  	  pinChar = pinString.charAt(index);	  	  		
 	  if (!Character.isLetterOrDigit(pinChar))
 	  {
 	    isInvalidCharFound = true;
 	    break;
 	  }
 	  if (isPINNumeric)
 	  {
 	    if (!Character.isDigit(pinChar))
 	    {
  	      isPINNumeric = false;
 	    }
 	    else
 	    {
 	      numericPinStringByteArray[index] = (byte) Character.digit(pinChar, DECIMAL_RADIX);
 	    }
 	  }
 	  PinStringByteArray[index] = (byte) pinChar;
  	}
  	
  	if (isInvalidCharFound)
  	{
  	  throw new PINBlockException("Error no : " + ERR_INVALID_PIN + " - Invalid PIN String");
  	}
  	else
  	{
  	  if (isPINNumeric)
 	  {
 	  	createFormat2PINBlock(numericPinStringByteArray);
 	  }
 	  else
 	  {
 	  	createFormat12PINBlock(PinStringByteArray);
 	  }
  	}
  	
  	return;
  }
  
  private void createFormat2PINBlock(byte[] numericPinByteArray)
  {
  	int tempInt;
  	
  	PINBlockType = ISO_FORMAT_2_TYPE;
  	PINBlockLength = NUM_OF_BYTES_IN_FMT2_PIN_BLOCK;
  	PINBlockByteArray = new byte[NUM_OF_BYTES_IN_FMT2_PIN_BLOCK];
	OBMApplet.fillByteArray(PINBlockByteArray, PIN_BLOCK_FILL_CHARACTER);
  	tempInt = FMT_2_CONTROL_BYTE << 4;
	PINBlockByteArray[0] = (byte) (tempInt | (PINLength & 0x00FF));
 	OBMApplet.convertAsciiArrayToHexByteArray(numericPinByteArray, PINBlockByteArray, 1, PINLength);
  	return;
  }
  
  private void createFormat12PINBlock(byte[] PinStringByteArray)
  {
  	PINBlockType = ISO_FORMAT_12_TYPE;
  	
  	if (PINLength <= 6)
  	{
  	  numberOfPINBlocks = 1; 
  	}
  	else
  	{
  	  numberOfPINBlocks = 2 + (PINLength - 7) / NUM_OF_BYTES_IN_FMT2_PIN_BLOCK; 
  	}
  	
  	PINBlockLength = numberOfPINBlocks * NUM_OF_BYTES_IN_FMT2_PIN_BLOCK;
  	
  	switch (numberOfPINBlocks)
  	{
  	  case 1:  	        
  	    PINBlockByteArray = new byte[NUM_OF_BYTES_IN_FMT2_PIN_BLOCK];
  	    break;
  	       
  	  case 2:  	        
  	    PINBlockByteArray = new byte[2 * NUM_OF_BYTES_IN_FMT2_PIN_BLOCK];
  	    break;
  	        
  	  case 3:  	        
  	    PINBlockByteArray = new byte[3 * NUM_OF_BYTES_IN_FMT2_PIN_BLOCK];
  	    break;
  	        
  	  default:
  	    PINBlockByteArray = new byte[4 * NUM_OF_BYTES_IN_FMT2_PIN_BLOCK];
  	}

	OBMApplet.fillByteArray(PINBlockByteArray, PIN_BLOCK_FILL_CHARACTER);
	PINBlockByteArray[0] = (byte) FMT_12_CONTROL_BYTE;
	PINBlockByteArray[1] = (byte) PINLength;
  	System.arraycopy(PinStringByteArray, 0, PINBlockByteArray, 2, PINLength);	    
  	return;
  }
  
  public byte[] getBytes()
  {
  	return PINBlockByteArray;
  }

  public int length()
  {
  	return PINBlockLength; 	
  } 
  
  public int getPINBlockType()
  {
  	return PINBlockType;
  }
 
}

