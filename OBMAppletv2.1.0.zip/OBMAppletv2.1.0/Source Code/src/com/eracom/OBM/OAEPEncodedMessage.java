package com.eracom.OBM;

import java.util.Random;

public class OAEPEncodedMessage implements Custom , Constants
{
  // constants
/* OAEP_SHA1_OFFSET_IN_BYTES = 2*(SHA1_HASH_SIZE_IN_BYTES) +2 = 42*/
/* OAEP_SHA2_224_OFFSET_IN_BYTES = 2*(SHA2_224_HASH_SIZE_IN_BYTES) +2 = 58*/
/* OAEP_SHA2_256_OFFSET_IN_BYTES = 2*(SHA2_256_HASH_SIZE_IN_BYTES) +2 = 66*/
/* OAEP_SHA2_384_OFFSET_IN_BYTES = 2*(SHA2_384_HASH_SIZE_IN_BYTES) +2 = 98*/
/* OAEP_SHA2_512_OFFSET_IN_BYTES = 2*(SHA2_512_HASH_SIZE_IN_BYTES) +2 = 130*/
  private static final int ENCODING_PARAMETER_SIZE_IN_BYTES = 16;
  private static final int SHA1_HASH_SIZE_IN_BYTES = 20;
  private static final int SHA2_224_HASH_SIZE_IN_BYTES = 28;
  private static final int SHA2_256_HASH_SIZE_IN_BYTES = 32;
  private static final int SHA2_384_HASH_SIZE_IN_BYTES = 48;
  private static final int SHA2_512_HASH_SIZE_IN_BYTES = 64;
  private static int HASH_ALGO_SIZE_IN_BYTES = 20;//using SHA1 size by default
  
  private static final int OAEP_SHA1_OFFSET_IN_BYTES = 42;
  private static final int OAEP_SHA2_224_OFFSET_IN_BYTES = 58;
  private static final int OAEP_SHA2_256_OFFSET_IN_BYTES = 66;
  private static final int OAEP_SHA2_384_OFFSET_IN_BYTES = 98;
  private static final int OAEP_SHA2_512_OFFSET_IN_BYTES = 130;
  
  private static final int MIN_PIN_MESSAGE_SIZE_IN_BYTES = 17;	// 1 + PINBlock size (8) + Min Random No size (8)

  private static final int NUM_OF_BYTES_PER_WORD = 4;

  private static int MAX_PIN_MESSAGE_SIZE_IN_BYTES = OBMApplet.RSA_MODULUS_SIZE_IN_BYTES - OAEP_SHA1_OFFSET_IN_BYTES;
  private static int ENCODED_MESSAGE_SIZE_IN_BYTES = OBMApplet.RSA_MODULUS_SIZE_IN_BYTES - 1;
  private static int DATA_BLOCK_SIZE_IN_BYTES = ENCODED_MESSAGE_SIZE_IN_BYTES - SHA1_HASH_SIZE_IN_BYTES;
  
  
  // variables
  private byte[] encodedMsgByteArray;
  private int encodedMsgLength;
  private String encodedMessageString;
  private String encodingParameterString;
  private byte[] P = new byte[ENCODING_PARAMETER_SIZE_IN_BYTES];

    
  // constructor
  public OAEPEncodedMessage(PINMessage pinMessage) throws OAEPEncodedMsgException 
  {
	
	if(customer == UOB)
	{
		MAX_PIN_MESSAGE_SIZE_IN_BYTES = OBMApplet.RSA_MODULUS_SIZE_IN_BYTES - OAEP_SHA1_OFFSET_IN_BYTES;
	    ENCODED_MESSAGE_SIZE_IN_BYTES = OBMApplet.RSA_MODULUS_SIZE_IN_BYTES - 1;
		DATA_BLOCK_SIZE_IN_BYTES = ENCODED_MESSAGE_SIZE_IN_BYTES - SHA1_HASH_SIZE_IN_BYTES;
	}

	encodedMsgByteArray = new byte[ENCODED_MESSAGE_SIZE_IN_BYTES];
    encodedMsgByteArray = doOAEPEncoding(pinMessage);
	encodedMessageString = OBMApplet.convertHexArrayToString(encodedMsgByteArray);
	encodingParameterString = OBMApplet.convertHexArrayToString(P);
  }
  

  // constructor
  public OAEPEncodedMessage(PINMessage pinMessage,String Hash_String) throws OAEPEncodedMsgException 
  {
	
	if(customer == UOB)
	{
	    MAX_PIN_MESSAGE_SIZE_IN_BYTES = OBMApplet.RSA_MODULUS_SIZE_IN_BYTES - OAEP_SHA1_OFFSET_IN_BYTES;
	    ENCODED_MESSAGE_SIZE_IN_BYTES = OBMApplet.RSA_MODULUS_SIZE_IN_BYTES - 1;
	    DATA_BLOCK_SIZE_IN_BYTES = ENCODED_MESSAGE_SIZE_IN_BYTES - SHA1_HASH_SIZE_IN_BYTES;
	}
	
	if(Hash_String.equalsIgnoreCase("SHA1"))
	{	
			HASH_ALGO_SIZE_IN_BYTES = SHA1_HASH_SIZE_IN_BYTES;
			MAX_PIN_MESSAGE_SIZE_IN_BYTES = OBMApplet.RSA_MODULUS_SIZE_IN_BYTES - OAEP_SHA1_OFFSET_IN_BYTES;
			DATA_BLOCK_SIZE_IN_BYTES = ENCODED_MESSAGE_SIZE_IN_BYTES - SHA1_HASH_SIZE_IN_BYTES;
	}
	else if(Hash_String.equalsIgnoreCase("SHA2-224"))
	{
			HASH_ALGO_SIZE_IN_BYTES = SHA2_224_HASH_SIZE_IN_BYTES;
			MAX_PIN_MESSAGE_SIZE_IN_BYTES = OBMApplet.RSA_MODULUS_SIZE_IN_BYTES - OAEP_SHA2_224_OFFSET_IN_BYTES;
			DATA_BLOCK_SIZE_IN_BYTES = ENCODED_MESSAGE_SIZE_IN_BYTES - SHA2_224_HASH_SIZE_IN_BYTES;
	}
	else if(Hash_String.equalsIgnoreCase("SHA2-256"))
	{
			HASH_ALGO_SIZE_IN_BYTES = SHA2_256_HASH_SIZE_IN_BYTES;
			MAX_PIN_MESSAGE_SIZE_IN_BYTES = OBMApplet.RSA_MODULUS_SIZE_IN_BYTES - OAEP_SHA2_256_OFFSET_IN_BYTES;
			DATA_BLOCK_SIZE_IN_BYTES = ENCODED_MESSAGE_SIZE_IN_BYTES - SHA2_256_HASH_SIZE_IN_BYTES;	
	}
	else if(Hash_String.equalsIgnoreCase("SHA2-384"))
	{
			HASH_ALGO_SIZE_IN_BYTES = SHA2_384_HASH_SIZE_IN_BYTES;
			MAX_PIN_MESSAGE_SIZE_IN_BYTES = OBMApplet.RSA_MODULUS_SIZE_IN_BYTES - OAEP_SHA2_384_OFFSET_IN_BYTES;
			DATA_BLOCK_SIZE_IN_BYTES = ENCODED_MESSAGE_SIZE_IN_BYTES - SHA2_384_HASH_SIZE_IN_BYTES;	
	}
	else if(Hash_String.equalsIgnoreCase("SHA2-512"))
	{
			HASH_ALGO_SIZE_IN_BYTES = SHA2_512_HASH_SIZE_IN_BYTES;
			MAX_PIN_MESSAGE_SIZE_IN_BYTES = OBMApplet.RSA_MODULUS_SIZE_IN_BYTES - OAEP_SHA2_512_OFFSET_IN_BYTES;
			DATA_BLOCK_SIZE_IN_BYTES = ENCODED_MESSAGE_SIZE_IN_BYTES - SHA2_512_HASH_SIZE_IN_BYTES;	
	}
	else
	{
		throw new OAEPEncodedMsgException("Error No: " + ERR_INVALID_HASH + " Invalid Hash Algorithm ");
	}

	encodedMsgByteArray = new byte[ENCODED_MESSAGE_SIZE_IN_BYTES];
      encodedMsgByteArray = doOAEPEncoding(pinMessage, Hash_String);
	encodedMessageString = OBMApplet.convertHexArrayToString(encodedMsgByteArray);
	encodingParameterString = OBMApplet.convertHexArrayToString(P);
	
  }
  
  private byte[] doOAEPEncoding(PINMessage pinMessage) throws OAEPEncodedMsgException 
  {
      Byte[] pinMsgByteArray = new Byte[MAX_PIN_MESSAGE_SIZE_IN_BYTES];
      byte[] pinMsgbyteArray = new byte[MAX_PIN_MESSAGE_SIZE_IN_BYTES];
  	byte[] pHash = new byte[SHA1_HASH_SIZE_IN_BYTES];
  	byte[] DB = new byte[DATA_BLOCK_SIZE_IN_BYTES];
  	byte[] dbMask = new byte[DATA_BLOCK_SIZE_IN_BYTES];
  	byte[] maskedDB = new byte[DATA_BLOCK_SIZE_IN_BYTES];
  	byte[] seed = new byte[SHA1_HASH_SIZE_IN_BYTES];
  	byte[] seedMask = new byte[SHA1_HASH_SIZE_IN_BYTES];
  	byte[] maskedSeed = new byte[SHA1_HASH_SIZE_IN_BYTES];
  	
  	int pinMsgLength, offset, numberOfPaddingBytes;
  	
	if (pinMessage == null)
	{
  	  throw new OAEPEncodedMsgException("Error no : " + ERR_INVALID_PIN_MESSAGE + " - Invalid PIN Message");
	}
	
  	pinMsgLength = pinMessage.length();
  	
  	if (pinMsgLength < MIN_PIN_MESSAGE_SIZE_IN_BYTES ||
  	    pinMsgLength > MAX_PIN_MESSAGE_SIZE_IN_BYTES)
  	{
  	  throw new OAEPEncodedMsgException("Error no : " + ERR_INVALID_PIN_MESSAGE_LENGTH + " Invalid PIN message length");
  	}

  	pinMessage.getBytes(pinMsgByteArray);

	// generate Encoding Parameter
	Random randomGenerator = new Random();		// pseudo-random using current time
	randomGenerator.nextBytes(P);

	// calculate pHash
	SHA1 sha1 = new SHA1();
	pHash = sha1.doHash(P, ENCODING_PARAMETER_SIZE_IN_BYTES);
	
	// form DB by concatenating pHash, zero Padding string PS, padding byte 01 and M
	OBMApplet.fillByteArray(DB, 0);			// fill DB with zeroes
  	System.arraycopy(pHash, 0, DB, 0, SHA1_HASH_SIZE_IN_BYTES);
  	offset = SHA1_HASH_SIZE_IN_BYTES;
  	numberOfPaddingBytes = DATA_BLOCK_SIZE_IN_BYTES - SHA1_HASH_SIZE_IN_BYTES - pinMsgLength - 1;
	offset += numberOfPaddingBytes;
	DB[offset] = (byte) 0x01;
	offset++;
	copyByteArray(pinMsgByteArray, pinMsgbyteArray, pinMsgLength);
  	System.arraycopy(pinMsgbyteArray, 0, DB, offset, pinMsgLength);
  	
	// generate random seed
	randomGenerator.nextBytes(seed);
	
	// create data block mask using MGF1
	MGF1(seed, dbMask, DATA_BLOCK_SIZE_IN_BYTES);
	
	// create masked data block
	xorByteArrays(DB, dbMask, maskedDB);
	
	// create seed mask using MGF1
	MGF1(maskedDB, seedMask, SHA1_HASH_SIZE_IN_BYTES);
	
	// create masked seed
	xorByteArrays(seed, seedMask, maskedSeed);
	
	// form encodedMsgByteArray by concatenating maskedSeed and maskedDB
  	System.arraycopy(maskedSeed, 0, encodedMsgByteArray, 0, SHA1_HASH_SIZE_IN_BYTES);
  	System.arraycopy(maskedDB, 0, encodedMsgByteArray, SHA1_HASH_SIZE_IN_BYTES, DATA_BLOCK_SIZE_IN_BYTES);
  	
  	return encodedMsgByteArray;
  }

  
  private byte[] doOAEPEncoding(PINMessage pinMessage,String Hash_String) throws OAEPEncodedMsgException 
  {
    Byte[] pinMsgByteArray = new Byte[MAX_PIN_MESSAGE_SIZE_IN_BYTES];
    byte[] pinMsgbyteArray = new byte[MAX_PIN_MESSAGE_SIZE_IN_BYTES];
  	
  	byte[] DB = new byte[DATA_BLOCK_SIZE_IN_BYTES];
  	byte[] dbMask = new byte[DATA_BLOCK_SIZE_IN_BYTES];
  	byte[] maskedDB = new byte[DATA_BLOCK_SIZE_IN_BYTES];
  	
  	byte[] pHash = new byte[HASH_ALGO_SIZE_IN_BYTES];
  	byte[] seed = new byte[HASH_ALGO_SIZE_IN_BYTES];
  	byte[] seedMask = new byte[HASH_ALGO_SIZE_IN_BYTES];
  	byte[] maskedSeed = new byte[HASH_ALGO_SIZE_IN_BYTES];
  	
  	int pinMsgLength, offset, numberOfPaddingBytes;
  	
	if (pinMessage == null)
	{
  	  throw new OAEPEncodedMsgException("Error no : " + ERR_INVALID_PIN_MESSAGE + " - Invalid PIN Message");
	}
	
  	pinMsgLength = pinMessage.length();
  	
  	if (pinMsgLength < MIN_PIN_MESSAGE_SIZE_IN_BYTES ||
  	    pinMsgLength > MAX_PIN_MESSAGE_SIZE_IN_BYTES)
  	{
  	  throw new OAEPEncodedMsgException("Error no : " + ERR_INVALID_PIN_MESSAGE_LENGTH + " Invalid PIN message length");
  	}

  	pinMessage.getBytes(pinMsgByteArray);

	// generate Encoding Parameter
	Random randomGenerator = new Random();		// pseudo-random using current time

	randomGenerator.nextBytes(P);

	// calculate pHash
	SHA1 sha1 = new SHA1();
	SHA2 sha2;
	
	if(Hash_String.equalsIgnoreCase("SHA1"))
	{
		pHash = sha1.doHash(P, ENCODING_PARAMETER_SIZE_IN_BYTES);
	}
	else if(Hash_String.equalsIgnoreCase("SHA2-224"))
	{
		sha2 = new SHA2("SHA-224");
		pHash = sha2.digest(P);			
	}
	else if(Hash_String.equalsIgnoreCase("SHA2-256"))
	{
		sha2 = new SHA2("SHA-256");
		pHash = sha2.digest(P);		
	}
	else if(Hash_String.equalsIgnoreCase("SHA2-384"))
	{
		sha2 = new SHA2("SHA-384");
		pHash = sha2.digest(P);
	}
	else if(Hash_String.equalsIgnoreCase("SHA2-512"))
	{
		sha2 = new SHA2("SHA-512");
		pHash = sha2.digest(P);
	}
	else
	{
		throw new OAEPEncodedMsgException("Error No: " + ERR_INVALID_HASH + " Invalid Hash Algorithm ");
	}
		
	// form DB by concatenating pHash, zero Padding string PS, padding byte 01 and M
	OBMApplet.fillByteArray(DB, 0);			// fill DB with zeroes
  	System.arraycopy(pHash, 0, DB, 0, HASH_ALGO_SIZE_IN_BYTES);
  	offset = HASH_ALGO_SIZE_IN_BYTES;
  	numberOfPaddingBytes = DATA_BLOCK_SIZE_IN_BYTES - HASH_ALGO_SIZE_IN_BYTES - pinMsgLength - 1;
	offset += numberOfPaddingBytes;
	DB[offset] = (byte) 0x01;
	offset++;
	copyByteArray(pinMsgByteArray, pinMsgbyteArray, pinMsgLength);
	System.arraycopy(pinMsgbyteArray, 0, DB, offset, pinMsgLength);

	// generate random seed
    randomGenerator.nextBytes(seed);
	
	// create data block mask using MGF1
	MGF1(seed, dbMask, DATA_BLOCK_SIZE_IN_BYTES, Hash_String);
	
	// create masked data block
	xorByteArrays(DB, dbMask, maskedDB);
	
	// create seed mask using MGF1
	MGF1(maskedDB, seedMask, HASH_ALGO_SIZE_IN_BYTES, Hash_String);
	
	// create masked seed
	xorByteArrays(seed, seedMask, maskedSeed);
	
	// form encodedMsgByteArray by concatenating maskedSeed and maskedDB
  	System.arraycopy(maskedSeed, 0, encodedMsgByteArray, 0, HASH_ALGO_SIZE_IN_BYTES);
  	System.arraycopy(maskedDB, 0, encodedMsgByteArray, HASH_ALGO_SIZE_IN_BYTES, DATA_BLOCK_SIZE_IN_BYTES);
  	   
  	return encodedMsgByteArray;
  }
  
  private void MGF1(byte[] Z, byte[] T, int l, String Hash_String) throws OAEPEncodedMsgException
  {
  	byte[] C = new byte[NUM_OF_BYTES_PER_WORD];
  	byte[] tempArray = new byte[ENCODED_MESSAGE_SIZE_IN_BYTES];
  	byte[] hashArray = new byte[HASH_ALGO_SIZE_IN_BYTES];
  	
  	int maxCount, seedLength, offset, remainingBytes, numberOfBytesToCopy;
  	seedLength = Z.length;
  	maxCount = l / HASH_ALGO_SIZE_IN_BYTES;
  	remainingBytes = l - maxCount * HASH_ALGO_SIZE_IN_BYTES;

  	// set limit to allow for extra calculation which can then be truncated
    if (remainingBytes > 0)
  	{
  	  maxCount++;
  	}
  	numberOfBytesToCopy = HASH_ALGO_SIZE_IN_BYTES;
	byte[] tempArray2 = new byte[seedLength + NUM_OF_BYTES_PER_WORD];
	
  	for (int counter = 0; counter < maxCount; counter++)
  	{
  	  I2OSP(counter, C, 0);	
  	  System.arraycopy(Z, 0, tempArray, 0, seedLength);
  	  System.arraycopy(C, 0, tempArray, seedLength, NUM_OF_BYTES_PER_WORD);

  	 // calculate hash(Z||C)
  	 // calculate pHash
  	SHA1 sha1 = new SHA1();
  	SHA2 sha2;
  	System.arraycopy(tempArray, 0, tempArray2, 0, seedLength+NUM_OF_BYTES_PER_WORD);
  	
  	if(Hash_String.equalsIgnoreCase("SHA1"))
  	{
   		hashArray = sha1.doHash(tempArray, (seedLength + NUM_OF_BYTES_PER_WORD));
  	}
  	else if(Hash_String.equalsIgnoreCase("SHA2-224"))
  	{
  		sha2 = new SHA2("SHA-224");
  		hashArray = sha2.digest(tempArray2);
  	}
  	else if(Hash_String.equalsIgnoreCase("SHA2-256"))
  	{
  		sha2 = new SHA2("SHA-256");
  		hashArray = sha2.digest(tempArray2);
  	}
  	else if(Hash_String.equalsIgnoreCase("SHA2-384"))
  	{
  		sha2 = new SHA2("SHA-384");
  		hashArray = sha2.digest(tempArray2);
  	}
  	else if(Hash_String.equalsIgnoreCase("SHA2-512"))
  	{
  		sha2 = new SHA2("SHA-512");
  		hashArray = sha2.digest(tempArray2);
  	}
  	else
  	{
  		throw new OAEPEncodedMsgException("From MGF1 Error No: " + ERR_INVALID_HASH + " Invalid Hash Algorithm ");
  	}
  	  
	  offset = counter * HASH_ALGO_SIZE_IN_BYTES;
		  
	  // on last count only transfer remaining bytes
	  if (counter == (maxCount - 1) &&
	      remainingBytes > 0)
	  {
	  	numberOfBytesToCopy = remainingBytes;
	  }
			  
  	  System.arraycopy(hashArray, 0, T, offset, numberOfBytesToCopy);
  	}

  	return;
  }

  
  private void MGF1(byte[] Z, byte[] T, int l)
  {
  	byte[] C = new byte[NUM_OF_BYTES_PER_WORD];
  	byte[] tempArray = new byte[ENCODED_MESSAGE_SIZE_IN_BYTES];
  	byte[] hashArray = new byte[SHA1_HASH_SIZE_IN_BYTES];
  	
  	int maxCount, seedLength, offset, remainingBytes, numberOfBytesToCopy;
  	
  	seedLength = Z.length;
  	maxCount = l / SHA1_HASH_SIZE_IN_BYTES;
  	remainingBytes = l - maxCount * SHA1_HASH_SIZE_IN_BYTES;
  	
	// set limit to allow for extra calculation which can then be truncated
    if (remainingBytes > 0)
  	{
  	  maxCount++;
  	}
  	
	numberOfBytesToCopy = SHA1_HASH_SIZE_IN_BYTES;
  	
  	for (int counter = 0; counter < maxCount; counter++)
  	{
  	  I2OSP(counter, C, 0);		
  	  System.arraycopy(Z, 0, tempArray, 0, seedLength);
  	  System.arraycopy(C, 0, tempArray, seedLength, NUM_OF_BYTES_PER_WORD);
  	  
	  // calculate hash(Z||C)
	  SHA1 sha1 = new SHA1();
	  hashArray = sha1.doHash(tempArray, (seedLength + NUM_OF_BYTES_PER_WORD));
	  offset = counter * SHA1_HASH_SIZE_IN_BYTES;
	  
	  // on last count only transfer remaining bytes
	  if (counter == (maxCount - 1) &&
	      remainingBytes > 0)
	  {
	  	numberOfBytesToCopy = remainingBytes;
	  }
			  
  	  System.arraycopy(hashArray, 0, T, offset, numberOfBytesToCopy);
  	}

  	return;
  }


  private void xorByteArrays(byte[] byteArray1, byte[] byteArray2, byte[] resultByteArray)
  {
  	int index, byteArrayLength;
  	
  	byteArrayLength = byteArray1.length;

  	for (index = 0; index < byteArrayLength; index++)
  	{  		
 	  resultByteArray[index] = (byte) ((int) byteArray1[index] ^ (int) byteArray2[index]);
  	}
  		
    return;
  }
  
  private void I2OSP(int inputWord, byte[] byteArray, int arrayOffset)
  {
  	byteArray[arrayOffset] = (byte) (inputWord >>> 24);
  	byteArray[arrayOffset + 1] = (byte) (inputWord >>> 16);
  	byteArray[arrayOffset + 2] = (byte) (inputWord >>> 8);
  	byteArray[arrayOffset + 3] = (byte) inputWord;  	
  	return;
  }
  
  private void copyByteArray(Byte[] srcByteArray, byte[] destByteArray, int NumOfBytesToCopy)
  {
  	for (int index = 0; index < NumOfBytesToCopy; index++)
  	{  		
 	  destByteArray[index] = srcByteArray[index].byteValue();
  	}
  	return;
  }
  
  public byte[] getBytes()
  {
  	return encodedMsgByteArray;
  }

  public int length()
  {
  	return encodedMsgLength; 	
  } 
  
  public String getEncodingParameter()
  {
  	return encodingParameterString;
  }
}

