package com.eracom.OBM;

import java.math.BigInteger;

public class EncryptedMessage implements Custom , Constants
{
  // constants
  private static final int HEX_RADIX = 16;
  protected static int RSA_MODULUS_SIZE_IN_BYTES = OBMApplet.RSA_MODULUS_SIZE_IN_BYTES;
  
  
  // error codes
  private static final int ERR_INVALID_ENCODED_MSG_LENGTH = 40;

  // variables
  private String publicExponentString = OBMApplet.PUBLIC_EXPONENT_STRING;
  private String modulusString = OBMApplet.MODULUS_STRING;
  private BigInteger modulus;
  private BigInteger publicExponent;
  private int modulusSizeInBits, maxInputDataSizeInBytes, maxOutputDataSizeInBytes;
  private byte[] encMsgByteArray;
  
  // constructor
  public EncryptedMessage(OAEPEncodedMessage oaepEncMessage) throws EncryptedMessageException
  {
  	
	if(customer == UOB)					//if customer is UOB then only runtime change in RSA is supported 
	{	
		RSA_MODULUS_SIZE_IN_BYTES = OBMApplet.RSA_MODULUS_SIZE_IN_BYTES;
		publicExponentString = OBMApplet.PUBLIC_EXPONENT_STRING;
		modulusString = OBMApplet.MODULUS_STRING;
	}
	
	// check that Public key data values have been initialised
  	if (RSA_MODULUS_SIZE_IN_BYTES == 0 ||
  	    modulusString == null ||
  	    publicExponentString == null)
  	{
      throw new EncryptedMessageException("Error no : " + ERR_INVALID_RSA_KEY + " Invalid RSA key");
  	}
  	
  	if (oaepEncMessage == null)
  	{
      throw new EncryptedMessageException("Error no : " + ERR_INVALID_ENCODED_MSG_LENGTH + " Invalid OAEP-encoded message length");
  	}
    
  	try
  	{
      modulus = new BigInteger(modulusString, HEX_RADIX);
      publicExponent = new BigInteger(publicExponentString, HEX_RADIX);
      validateRSAEncInputData(oaepEncMessage.length());         
      encMsgByteArray = doRSAEncryption(oaepEncMessage.getBytes());
  	}
  	catch (NumberFormatException e)		// check that RSA keys are valid numbers
  	{
      throw new EncryptedMessageException("Error no : " + ERR_INVALID_RSA_KEY + " Invalid RSA key");
  	}
  }
  
  private void validateRSAEncInputData(int inputDataLength) throws EncryptedMessageException
  {
    int modulusSizeInBytes = (modulusString.length() + 1) / 2;
    int publicExponentSizeInBytes = (publicExponentString.length() + 1) / 2;

    // check that modulus and exponent string sizes are correct
    if ((modulusSizeInBytes != RSA_MODULUS_SIZE_IN_BYTES) ||
        (publicExponentSizeInBytes != RSA_MODULUS_SIZE_IN_BYTES))
    {
      throw new EncryptedMessageException("Error no : " + ERR_INVALID_RSA_KEY_LENGTH + " Invalid RSA key length");
    }
    
    modulusSizeInBits = modulusSizeInBytes * 8; 
    maxOutputDataSizeInBytes = (modulusSizeInBits + 7) / 8;
    maxInputDataSizeInBytes = maxOutputDataSizeInBytes - 1;
    
    // check that input data size < key size
  	if (inputDataLength > (maxInputDataSizeInBytes + 1))
  	{
      throw new EncryptedMessageException("Error no : " + ERR_INVALID_ENCODED_MSG_LENGTH + " input data too large for RSA encryption");
  	}
    
  	return;
  }
  
  private byte[] doRSAEncryption(byte[] inputDataByteArray) 
  {
  	BigInteger inputData, outputData;
  	byte [] outputDataArray;

  	inputData = new BigInteger(1, inputDataByteArray);
  	outputData = inputData.modPow(publicExponent, modulus);
  	outputDataArray = adjustEncryptedDataLength(outputData.toByteArray());
  	return outputDataArray;
  }
  
  private byte[] adjustEncryptedDataLength(byte [] encDataArray)
  {
  	int encDataLength, adjDataLength;
  	byte[] adjustedDataArray;
  	
  	encDataLength = encDataArray.length;
  	
  	if (encDataArray[0] == 0 &&
  	    encDataLength > maxOutputDataSizeInBytes)
  	{
  	  adjDataLength = encDataLength - 1;
  	  adjustedDataArray = new byte[adjDataLength];
  	  System.arraycopy(encDataArray, 1, adjustedDataArray, 0, adjDataLength);
  	  return adjustedDataArray;
  	}
  	else
  	if (encDataLength < maxOutputDataSizeInBytes)
  	{  
  	  adjustedDataArray = new byte[maxOutputDataSizeInBytes];
  	  System.arraycopy(encDataArray, 0, adjustedDataArray,
  	                   (maxOutputDataSizeInBytes - encDataLength), encDataLength);
  	  return adjustedDataArray;
  	}
  	
  	return encDataArray;
  }

  
  public byte[] getBytes()
  {
  	return encMsgByteArray;
  }

  public int length()
  {
  	return encMsgByteArray.length; 	
  }  
}

