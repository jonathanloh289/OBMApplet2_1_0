package com.eracom.OBM;

public class PINBlockException extends Exception
{
  /**
   * Constructor for PINBlockFormatException
   */
  static final long serialVersionUID = -2740153767582114766L;
  public PINBlockException()
  {
    super();
  }

  /**
   * Constructor for PINBlockFormatException
   */
  public PINBlockException(String msg)
  {
    super(msg);
  }
}

