/*
 * Created on 1/07/2004
 *
 */
package com.eracom.OBM;

/**
 * @author Jeff Manson
 *
 */
public class PublicKeyData
{
  // value can be 768, 896, 1024, 1152 or 1280
  protected static final int RSA_MODULUS_SIZE_IN_BITS = 0;		

  // This is hex string same length as modulus string
  protected static final String PUBLIC_EXPONENT_STRING = "";	

  // This is hex string with twice no of chars as modulus size in bytes 
  protected static final String MODULUS_STRING = "";

}
